echo ttyO1 > /sys/devices/bone_capemgr.9/slots
