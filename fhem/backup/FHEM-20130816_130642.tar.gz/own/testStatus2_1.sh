echo 1 > ./own/Test_Status2
