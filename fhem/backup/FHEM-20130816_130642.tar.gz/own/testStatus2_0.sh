echo 0 > ./own/Test_Status2
